# Youtube Livestream Viewbot

Youtube Livestream Viewbot application developed in C#.

## Prerequisites

* [HTTP Proxies](https://proxyscrape.com/free-proxy-list)
* [Visual Studio 2019](https://visualstudio.microsoft.com/vs/) is used to develop computer programs, as well as websites, web apps, web services and mobile apps.

## Usage

Run the compiled EXE.

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License

MIT


 <i style='text-align: center; color: red;font-size: 13px;'>CopyRight © lastmalware 2021</i> 
